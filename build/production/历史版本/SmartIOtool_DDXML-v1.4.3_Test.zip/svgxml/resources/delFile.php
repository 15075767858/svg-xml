<?php
$fn=$_GET['fileName'];
echo unlink($fn);
?>